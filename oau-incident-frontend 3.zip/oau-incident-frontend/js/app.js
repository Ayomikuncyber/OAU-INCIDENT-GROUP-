(function () {
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)], app = $("#app");
  const CATS = ["Infrastructure", "Security", "Lost & Found", "Water & Power", "Sanitation", "Other"];
  const PLACES = ["Awolowo Hall", "Moremi Hall", "Angola Hall", "Mozambique Hall", "Fajuyi Hall", "Akintola Hall", "Alumni Hall", "Student Union Building", "Hezekiah Oluwasanmi Library", "Amphitheatre", "Oduduwa Hall", "Parks and Gardens"];
  const DAY = 864e5, OVERDUE = 3 * DAY;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const mask = e => e.replace(/^(.{2}).*@/, "$1•••@");
  const ago = iso => {
    const m = Math.max(1, Math.round((Date.now() - new Date(iso)) / 6e4));
    if (m < 60) return m + " min ago";
    const h = Math.round(m / 60); if (h < 24) return h + " hr ago";
    const d = Math.round(h / 24); return d + (d === 1 ? " day ago" : " days ago");
  };
  const isLate = i => i.status === "Pending" && Date.now() - new Date(i.createdAt) > OVERDUE;
  let me = API.session(), items = [], filt = { status: "all", cat: "all", q: "" }, flash = null, poll = null;
  let adm = { status: "Pending", cat: "all", q: "", sort: "new", limit: 15 }, sel = new Set();

  function toast(msg, undo) {
    const t = document.createElement("div"); t.className = "toast"; t.append(msg);
    if (undo) {
      const b = document.createElement("button"); b.textContent = "Undo";
      b.onclick = () => { t.remove(); undo(); }; t.append(b);
    }
    $("#toasts").append(t); setTimeout(() => t.remove(), undo ? 6500 : 3200);
  }
  const go = h => { location.hash = h; };
  const isAdmin = () => me && me.role === "admin";
  const openCount = () => items.filter(i => i.status === "Pending").length;

  function shell(inner, active, wide) {
    const open = openCount();
    return `<header class="top"><a class="brand" href="${isAdmin() ? "#/admin" : "#/feed"}"><span class="mark">OAU</span><span>Incident System</span></a>
      <nav aria-label="Main">${isAdmin() ? `<a href="#/admin" class="${active === "admin" ? "on" : ""}">Admin dashboard</a>` : ""}
      <a href="#/report" class="${active === "report" ? "on" : ""}">Report an issue</a>
      <a href="#/feed" id="navfeed" class="${active === "feed" ? "on" : ""}">Campus feed${open ? `<b class="count">${open}</b>` : ""}</a></nav>
      <div class="who"><span class="avatar" aria-hidden="true">${esc(me.email.charAt(0).toUpperCase())}</span><span class="email">${esc(me.email)}</span>${isAdmin() ? '<span class="role">Authority</span>' : ""}
      <button class="ghost" id="out">Sign out</button></div></header><main class="${wide ? "wide" : ""}">${inner}</main>`;
  }
  function bindShell() { $("#out").onclick = () => { API.logout(); clearInterval(poll); me = null; sel.clear(); go("#/login"); }; }
  function syncBadge() {
    const a = $("#navfeed"), n = openCount(); if (!a) return;
    a.innerHTML = "Campus feed" + (n ? `<b class="count">${n}</b>` : "");
  }

  /* ---------- Status changes (shared by feed + admin) ---------- */
  async function setStatus(ids, to) {
    const prev = ids.map(id => [id, (items.find(i => i.id === id) || {}).status]).filter(p => p[1] && p[1] !== to);
    if (!prev.length) return;
    try { await Promise.all(prev.map(p => API.setStatus(p[0], to))); }
    catch (x) { toast(x.message); await refresh(); return; }
    toast((to === "Resolved" ? "Marked resolved" : "Reopened") + (prev.length > 1 ? " (" + prev.length + " reports)" : ""), async () => {
      try { await Promise.all(prev.map(p => API.setStatus(p[0], p[1]))); await refresh(); } catch (x) { toast(x.message); }
    });
    await refresh();
  }
  async function refresh() {
    try { items = await API.list(); } catch (e) { if ($("#list") || $("#tbody")) toast(e.message); return; }
    if ($("#list")) paintList();
    if ($("#tbody")) paintAdmin();
    syncBadge();
  }

  /* ---------- Login ---------- */
  function login() {
    app.innerHTML = `<div class="login"><section class="hero"><div class="mark big">OAU</div>
      <h1>See it broken?<br>Report it once.</h1>
      <p>Every report goes to the people who can fix it, and everyone on campus can see where it stands.</p>
      <div class="slips" aria-hidden="true"><div class="slip"><div><strong>Moremi Hall, Block C</strong><span>No running water on the second floor.</span></div>
      <span class="pill pending" id="demo-pill"><i></i><em>Pending</em></span></div>
      <div class="slip two"><div><strong>Road to Alumni Hall</strong><span>Streetlights are out after 8pm.</span></div><span class="pill resolved"><i></i><em>Resolved</em></span></div></div></section>
      <section class="panel"><h2>Sign in</h2><p class="muted">Only @oauife.edu.ng email addresses can sign in.</p>
      <form id="lf" novalidate><label>University email<input type="email" name="email" placeholder="matric.name@oauife.edu.ng" autocomplete="username" required></label>
      <label>Password<input type="password" name="pw" autocomplete="current-password" required></label>
      <p class="err" id="err" role="alert"></p><button class="btn" type="submit">Sign in</button></form>
      ${API.demo ? '<p class="note">Demo mode: reports are saved in this browser. Any password with 6+ characters works. Sign in as <b>admin@oauife.edu.ng</b> to use the admin dashboard.</p>' : ""}</section></div>`;
    setTimeout(() => { const p = $("#demo-pill"); if (p) { p.className = "pill resolved"; p.querySelector("em").textContent = "Resolved"; } }, 2000);
    $("#lf").onsubmit = async e => {
      e.preventDefault(); const f = e.target, err = $("#err"), b = f.querySelector("button");
      err.textContent = ""; b.disabled = true; b.textContent = "Signing in…";
      try { me = await API.login(f.email.value, f.pw.value); go(isAdmin() ? "#/admin" : "#/report"); }
      catch (x) { err.textContent = x.message; b.disabled = false; b.textContent = "Sign in"; }
    };
  }

  /* ---------- Report ---------- */
  async function report() {
    try { items = await API.list(); } catch (e) { items = []; }
    app.innerHTML = shell(`<div class="two"><section><h1>Report an issue</h1>
      <p class="muted">Check the matches on the right first. If it's already reported, there's nothing more to do.</p>
      <form id="rf" novalidate><fieldset><legend>What kind of issue is it?</legend><div class="chips">
      ${CATS.map((c, i) => `<label class="chip"><input type="radio" name="cat" value="${esc(c)}" ${i === 0 ? "checked" : ""}><span>${esc(c)}</span></label>`).join("")}</div></fieldset>
      <label>Where is it?<input name="loc" list="places" placeholder="e.g. Awolowo Hall, Block B" maxlength="120" autocomplete="off"></label>
      <datalist id="places">${PLACES.map(p => `<option value="${p}">`).join("")}</datalist>
      <label>What's wrong?<textarea name="desc" rows="5" maxlength="500" placeholder="Say what you saw and since when."></textarea><small id="cnt">0 / 500</small></label>
      <p class="err" id="err" role="alert"></p><button class="btn" type="submit">Submit report</button></form></section>
      <aside class="panel"><h2>Already reported nearby</h2><div id="dupes"></div></aside></div>`, "report");
    bindShell();
    const f = $("#rf"), dupes = () => {
      const l = f.loc.value.trim().toLowerCase(), c = f.cat.value;
      const m = items.filter(i => i.status === "Pending" && (l.length > 2 ? i.location.toLowerCase().includes(l) : i.category === c)).slice(0, 4);
      $("#dupes").innerHTML = m.length ? m.map(i => `<div class="dupe"><strong>${esc(i.location)}</strong><span>${esc(i.description)}</span><small>${esc(i.category)} · ${ago(i.createdAt)}</small></div>`).join("")
        : `<p class="muted">No open reports match yet.</p>`;
    };
    f.oninput = () => { const n = f.desc.value.length, c = $("#cnt"); c.textContent = n + " / 500"; c.className = n > 450 ? "warn" : ""; dupes(); }; dupes();
    f.onsubmit = async e => {
      e.preventDefault(); const err = $("#err"), loc = f.loc.value.trim(), desc = f.desc.value.trim();
      if (!loc) { err.textContent = "Enter where the issue is."; return f.loc.focus(); }
      if (desc.length < 10) { err.textContent = "Describe the issue in at least 10 characters."; return f.desc.focus(); }
      const b = f.querySelector("button"); b.disabled = true; b.textContent = "Submitting…";
      try { const r = await API.create({ category: f.cat.value, location: loc, description: desc }); flash = r.id; toast("Report submitted"); go("#/feed"); }
      catch (x) { err.textContent = x.message; b.disabled = false; b.textContent = "Submit report"; }
    };
  }

  /* ---------- Feed ---------- */
  function visible() {
    const q = filt.q.toLowerCase();
    return items.filter(i => (filt.status === "all" || i.status === filt.status) && (filt.cat === "all" || i.category === filt.cat)
      && (!q || (i.location + " " + i.description).toLowerCase().includes(q)));
  }
  function paintList() {
    const p = openCount(), r = items.length - p, pc = items.length ? Math.round(p / items.length * 100) : 0;
    $("#sum").innerHTML = `<div class="bar" role="img" aria-label="${p} pending, ${r} resolved"><span style="width:${pc}%"></span></div>
      <p><b>${p}</b> pending <span class="sep"></span> <b>${r}</b> resolved</p>`;
    const v = visible();
    $("#list").innerHTML = v.length ? v.map(i => `<li class="row ${i.status.toLowerCase()} ${i.id === flash ? "new" : ""}">
      <div class="main"><div class="line"><strong>${esc(i.location)}</strong><span class="cat">${esc(i.category)}</span></div>
      <p>${esc(i.description)}</p><small>${esc(isAdmin() ? i.email : mask(i.email))} · ${ago(i.createdAt)}</small></div>
      <div class="side"><span class="pill ${i.status.toLowerCase()}"><i></i><em>${i.status}</em></span>
      ${isAdmin() ? `<button class="${i.status === "Pending" ? "btn sm" : "ghost sm"}" data-id="${esc(i.id)}" data-to="${i.status === "Pending" ? "Resolved" : "Pending"}">${i.status === "Pending" ? "Mark resolved" : "Reopen"}</button>` : ""}</div></li>`).join("")
      : `<li class="empty"><p>No reports match these filters.</p><a class="btn sm" href="#/report">Report an issue</a></li>`;
    flash = null;
  }
  async function feed() {
    app.innerHTML = shell(`<h1>Campus feed</h1><p class="muted">Every report across campus, newest first.</p><div id="sum" class="sum"></div>
      <div class="filters"><div class="seg" role="group" aria-label="Status">${["all", "Pending", "Resolved"].map(s => `<button data-s="${s}" class="${filt.status === s ? "on" : ""}">${s === "all" ? "All" : s}</button>`).join("")}</div>
      <select id="cat" aria-label="Category"><option value="all">All categories</option>${CATS.map(c => `<option ${filt.cat === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
      <input id="q" type="search" placeholder="Search location or description" value="${esc(filt.q)}"></div><ul id="list" class="feed"><li class="skel"></li><li class="skel"></li><li class="skel"></li></ul>`, "feed");
    bindShell(); await refresh();
    $$(".seg button").forEach(b => b.onclick = () => { filt.status = b.dataset.s; $$(".seg button").forEach(x => x.classList.toggle("on", x === b)); paintList(); });
    $("#cat").onchange = e => { filt.cat = e.target.value; paintList(); };
    $("#q").oninput = e => { filt.q = e.target.value; paintList(); };
    $("#list").onclick = async e => {
      const b = e.target.closest("button[data-id]"); if (!b) return; b.disabled = true;
      await setStatus([b.dataset.id], b.dataset.to);
    };
    clearInterval(poll); poll = setInterval(refresh, 20000);
  }

  /* ---------- Admin dashboard ---------- */
  function admView() {
    const q = adm.q.toLowerCase();
    let v = items.filter(i => (adm.status === "all" || i.status === adm.status) && (adm.cat === "all" || i.category === adm.cat)
      && (!q || (i.location + " " + i.description + " " + i.email).toLowerCase().includes(q)));
    const t = i => new Date(i.createdAt);
    if (adm.sort === "old") v = [...v].sort((a, b) => t(a) - t(b));
    if (adm.sort === "open") v = [...v].sort((a, b) => a.status === b.status ? t(a) - t(b) : a.status === "Pending" ? -1 : 1);
    return v;
  }
  function paintKpis() {
    const open = items.filter(i => i.status === "Pending"), done = items.length - open.length;
    const rate = items.length ? Math.round(done / items.length * 100) : 0, late = open.filter(isLate).length;
    const oldest = open.length ? ago(open.reduce((a, b) => new Date(a.createdAt) < new Date(b.createdAt) ? a : b).createdAt).replace(" ago", "") : "None";
    $("#kpis").innerHTML = `<div class="open"><b>${open.length}</b><span>Open reports</span></div>
      <div class="done"><b>${done}</b><span>Resolved (${rate}% of all reports)</span></div>
      <div class="${late ? "late" : ""}"><b>${late}</b><span>Waiting more than 3 days</span></div>
      <div><b>${esc(oldest)}</b><span>Longest open report</span></div>`;
  }
  function paintAttn() {
    const late = items.filter(isLate).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    $("#attn").innerHTML = late.length ? `<div class="attn"><h2>${late.length} ${late.length === 1 ? "report has" : "reports have"} waited more than 3 days</h2><p>Oldest first.</p><ul>
      ${late.slice(0, 3).map(i => `<li><div><strong>${esc(i.location)}</strong><small>${esc(i.category)} · <span class="age">open ${esc(ago(i.createdAt).replace(" ago", ""))}</span></small></div>
      <button class="btn sm" data-id="${esc(i.id)}" data-to="Resolved">Mark resolved</button></li>`).join("")}</ul></div>`
      : `<div class="attn ok"><p>Nothing has been waiting longer than 3 days.</p></div>`;
  }
  function paintTrend() {
    const days = [...Array(14)].map((_, k) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (13 - k)); return d; });
    const counts = days.map(d => { const e = new Date(d); e.setDate(e.getDate() + 1); return items.filter(i => { const t = new Date(i.createdAt); return t >= d && t < e; }).length; });
    const max = Math.max(1, ...counts), total = counts.reduce((a, b) => a + b, 0), fmt = d => d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
    $("#trend").innerHTML = `<svg viewBox="0 0 308 128" role="img" aria-label="${total} reports in the last 14 days, peak ${max} in a day">
      ${counts.map((c, k) => { const h = c ? Math.max(4, c / max * 84) : 3;
        return `<rect class="${c ? "b" : "z"}${k === 13 ? " today" : ""}" x="${k * 22 + 2}" y="${100 - h}" width="18" height="${h}" rx="3"><title>${fmt(days[k])}: ${c} ${c === 1 ? "report" : "reports"}</title></rect>`
          + (c ? `<text x="${k * 22 + 11}" y="${96 - h}" text-anchor="middle">${c}</text>` : ""); }).join("")}
      <text x="2" y="120">${fmt(days[0])}</text><text x="306" y="120" text-anchor="end">Today</text></svg>`;
  }
  function paintCats() {
    const names = [...new Set([...CATS, ...items.map(i => i.category)])];
    const rows = names.map(n => { const a = items.filter(i => i.category === n); return { n, t: a.length, p: a.filter(i => i.status === "Pending").length }; })
      .filter(r => r.t).sort((a, b) => b.t - a.t);
    const max = Math.max(1, ...rows.map(r => r.t));
    $("#cats").innerHTML = rows.length ? rows.map(r => `<li><div class="cl"><span>${esc(r.n)}</span><small>${r.p} open of ${r.t}</small></div>
      <div class="stack" role="img" aria-label="${r.p} open, ${r.t - r.p} resolved"><span class="p" style="width:${r.p / max * 100}%"></span><span class="r" style="width:${(r.t - r.p) / max * 100}%"></span></div></li>`).join("")
      : `<li class="muted">No reports yet.</li>`;
  }
  function arow(i) {
    const pend = i.status === "Pending", late = isLate(i);
    return `<tr class="${i.status.toLowerCase()} ${sel.has(i.id) ? "sel" : ""}">
      <td class="ck"><input type="checkbox" data-sel="${esc(i.id)}" ${sel.has(i.id) ? "checked" : ""} aria-label="Select report: ${esc(i.location)}"></td>
      <td class="issue"><strong>${esc(i.location)}</strong><span>${esc(i.description)}</span></td>
      <td><span class="cat">${esc(i.category)}</span></td>
      <td class="rep" data-label="Reporter">${esc(i.email)}</td>
      <td class="when ${late ? "late" : ""}" data-label="Reported">${ago(i.createdAt)}${late ? " (overdue)" : ""}</td>
      <td><span class="pill ${i.status.toLowerCase()}"><i></i><em>${i.status}</em></span></td>
      <td class="act"><button class="${pend ? "btn sm" : "ghost sm"}" data-id="${esc(i.id)}" data-to="${pend ? "Resolved" : "Pending"}">${pend ? "Mark resolved" : "Reopen"}</button></td></tr>`;
  }
  function paintBulk() {
    const chosen = items.filter(i => sel.has(i.id)), np = chosen.filter(i => i.status === "Pending").length, nr = chosen.length - np;
    const b = $("#bulk"); b.hidden = !chosen.length;
    b.innerHTML = `<span>${chosen.length} selected</span><button class="ghost" data-bulk="Resolved" ${np ? "" : "disabled"}>Mark resolved${np ? " (" + np + ")" : ""}</button>
      <button class="ghost" data-bulk="Pending" ${nr ? "" : "disabled"}>Reopen${nr ? " (" + nr + ")" : ""}</button><button class="ghost" data-bulk="clear">Clear</button>`;
  }
  function paintTable() {
    const ids = new Set(items.map(i => i.id)); [...sel].forEach(id => { if (!ids.has(id)) sel.delete(id); });
    const v = admView(), shown = v.slice(0, adm.limit);
    $("#tcount").textContent = v.length + (v.length === 1 ? " report" : " reports");
    $("#tbody").innerHTML = shown.length ? shown.map(arow).join("") : `<tr class="none"><td colspan="7">No reports match these filters.</td></tr>`;
    const more = $("#more"); more.hidden = v.length <= adm.limit; more.textContent = "Show more (" + (v.length - adm.limit) + " left)";
    $("#all").checked = shown.length > 0 && shown.every(i => sel.has(i.id));
    paintBulk();
  }
  function paintAdmin() {
    paintKpis(); paintAttn(); paintTrend(); paintCats();
    $("#aseg").innerHTML = ["Pending", "Resolved", "all"].map(s => `<button data-s="${s}" class="${adm.status === s ? "on" : ""}">${s === "all" ? "All" : s}<small>${s === "all" ? items.length : items.filter(i => i.status === s).length}</small></button>`).join("");
    paintTable();
  }
  const csvCell = v => { v = String(v == null ? "" : v); if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
  function exportCsv() {
    const rows = admView(), head = ["id", "reporter", "category", "location", "description", "status", "reported_at"];
    const text = [head.join(","), ...rows.map(i => [i.id, i.email, i.category, i.location, i.description, i.status, i.createdAt].map(csvCell).join(","))].join("\r\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + text], { type: "text/csv" }));
    a.download = "oau-incidents-" + new Date().toISOString().slice(0, 10) + ".csv"; document.body.append(a); a.click(); a.remove();
    toast("Exported " + rows.length + (rows.length === 1 ? " report" : " reports"));
  }
  async function admin() {
    app.innerHTML = shell(`<div class="head"><div><h1>Admin dashboard</h1><p class="muted">Close reports that are fixed and see what has been waiting longest.</p></div>
      <button class="ghost" id="csv">Export CSV</button></div>
      <section class="panel kpis" id="kpis" aria-label="Summary"></section><section id="attn"></section>
      <div class="charts"><section class="panel"><h2>Reports per day</h2><p class="muted sub">Last 14 days</p><div class="trend" id="trend"></div></section>
      <section class="panel"><h2>By category</h2><p class="muted sub"><span class="key p"></span>Open<span class="key r"></span>Resolved</p><ul class="cats" id="cats"></ul></section></div>
      <h2 class="sect">All reports <small id="tcount"></small></h2>
      <div class="filters"><div class="seg" id="aseg" role="group" aria-label="Status"></div>
      <select id="acat" aria-label="Category"><option value="all">All categories</option>${CATS.map(c => `<option ${adm.cat === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
      <select id="asort" aria-label="Sort"><option value="new">Newest first</option><option value="old">Oldest first</option><option value="open">Open longest first</option></select>
      <input id="aq" type="search" placeholder="Search location, description or email" value="${esc(adm.q)}"></div>
      <div class="bulk" id="bulk" hidden></div>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th class="ck"><input type="checkbox" id="all" aria-label="Select all shown reports"></th><th>Report</th><th>Category</th><th>Reporter</th><th>Reported</th><th>Status</th><th><span class="sr">Action</span></th></tr></thead>
      <tbody id="tbody"><tr class="none"><td colspan="7">Loading reports…</td></tr></tbody></table></div>
      <button class="ghost more" id="more" hidden></button>`, "admin", true);
    bindShell(); $("#asort").value = adm.sort;
    await refresh(); if (!$("#tbody")) return;
    const reset = () => { adm.limit = 15; paintTable(); };
    $("#csv").onclick = exportCsv;
    $("#aseg").onclick = e => { const b = e.target.closest("button[data-s]"); if (!b) return; adm.status = b.dataset.s; $$("#aseg button").forEach(x => x.classList.toggle("on", x === b)); reset(); };
    $("#acat").onchange = e => { adm.cat = e.target.value; reset(); };
    $("#asort").onchange = e => { adm.sort = e.target.value; reset(); };
    $("#aq").oninput = e => { adm.q = e.target.value; reset(); };
    $("#more").onclick = () => { adm.limit += 15; paintTable(); };
    $("#all").onchange = e => { admView().slice(0, adm.limit).forEach(i => e.target.checked ? sel.add(i.id) : sel.delete(i.id)); paintTable(); };
    $("#tbody").onchange = e => { const c = e.target.closest("input[data-sel]"); if (!c) return; c.checked ? sel.add(c.dataset.sel) : sel.delete(c.dataset.sel); paintTable(); };
    const act = async e => { const b = e.target.closest("button[data-id]"); if (!b) return; b.disabled = true; await setStatus([b.dataset.id], b.dataset.to); };
    $("#tbody").onclick = act; $("#attn").onclick = act;
    $("#bulk").onclick = async e => {
      const b = e.target.closest("button[data-bulk]"); if (!b) return;
      if (b.dataset.bulk === "clear") { sel.clear(); return paintTable(); }
      const ids = items.filter(i => sel.has(i.id)).map(i => i.id); sel.clear(); await setStatus(ids, b.dataset.bulk);
    };
    clearInterval(poll); poll = setInterval(refresh, 20000);
  }

  function route() {
    clearInterval(poll); me = API.session();
    const h = location.hash || (isAdmin() ? "#/admin" : "#/feed");
    if (!me) return login();
    if (h === "#/report") return report();
    if (h === "#/login") return go(isAdmin() ? "#/admin" : "#/feed");
    if (h === "#/admin") {
      if (!isAdmin()) { toast("The admin dashboard is for Authority accounts."); return go("#/feed"); }
      return admin();
    }
    feed();
  }
  window.addEventListener("hashchange", route); route();
})();
