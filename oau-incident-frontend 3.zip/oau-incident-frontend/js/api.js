// All backend calls live in this file. Adjust the paths/fields below to match the real API.
(function () {
  const C = window.APP_CONFIG, SK = "oau.session", DB = "oau.incidents.v2", demo = !C.API_BASE;
  const hrs = h => new Date(Date.now() - h * 36e5).toISOString();
  const norm = r => ({
    id: r.id, email: r.email || r.reporter_email || r.reporterEmail || "",
    category: r.category, location: r.location, description: r.description,
    status: /resolved/i.test(r.status) ? "Resolved" : "Pending",
    createdAt: r.createdAt || r.created_at
  });
  const domainOk = e => e.toLowerCase().endsWith("@" + C.ALLOWED_DOMAIN) && /^[^\s@]+@[^\s@]+$/.test(e);

  function seed() {
    if (localStorage.getItem(DB)) return;
    const E = n => n + "@" + C.ALLOWED_DOMAIN;
    const s = [
      [E("tolu.a1932"), "Water & Power", "Moremi Hall, Block C", "No running water on the second floor since Monday morning.", 2, "Pending"],
      [E("amaka.u2015"), "Infrastructure", "Hezekiah Oluwasanmi Library", "Two of the lifts near the main entrance are out of service again.", 5, "Pending"],
      [E("chidi.n2041"), "Security", "Road to Alumni Hall", "Streetlights are out along the whole stretch. Unsafe after 8pm.", 7, "Pending"],
      [E("bayo.k1999"), "Sanitation", "Mozambique Hall, Block A", "Blocked drain behind the block, the smell is getting worse every day.", 14, "Pending"],
      [E("fatima.s1805"), "Infrastructure", "Awolowo Hall, Block B", "Ceiling fan in the corridor is hanging loose from the ceiling.", 20, "Pending"],
      [E("kunle.o2210"), "Lost & Found", "Hezekiah Oluwasanmi Library", "Found a black Casio calculator on the 2nd floor reading desk.", 30, "Resolved"],
      [E("ngozi.e1977"), "Sanitation", "Student Union Building", "Overflowing bins behind the cafeteria are attracting flies.", 52, "Resolved"],
      [E("yemi.a2230"), "Water & Power", "Fajuyi Hall", "Transformer humming loudly and the lights flicker every evening.", 66, "Pending"],
      [E("sade.b2102"), "Infrastructure", "Amphitheatre", "Broken seats in the front rows, two of them have sharp edges.", 96, "Resolved"],
      [E("ife.m1888"), "Water & Power", "Angola Hall", "Prepaid meter room has been locked for three days.", 120, "Pending"],
      [E("dami.o2144"), "Security", "Parks and Gardens", "Gate near the garden has no lock and people loiter there at night.", 150, "Pending"],
      [E("zainab.l1920"), "Other", "Oduduwa Hall", "Notice board glass is shattered and exposed to anyone passing.", 190, "Resolved"],
      [E("emeka.c2078"), "Water & Power", "Akintola Hall", "Taps in the male toilets have been dry for a week.", 214, "Resolved"],
      [E("ruth.a1966"), "Lost & Found", "Student Union Building", "Found a bunch of keys with a red tag near the photocopy shop.", 260, "Resolved"],
      [E("tunde.f2189"), "Infrastructure", "Alumni Hall", "Large pothole at the hall entrance fills with water when it rains.", 300, "Pending"]
    ].map((r, i) => ({ id: "d" + i, email: r[0], category: r[1], location: r[2], description: r[3], createdAt: hrs(r[4]), status: r[5] }));
    localStorage.setItem(DB, JSON.stringify(s));
  }
  const read = () => JSON.parse(localStorage.getItem(DB) || "[]");
  const sess = () => { try { return JSON.parse(localStorage.getItem(SK)); } catch (e) { return null; } };
  async function http(path, opt = {}) {
    const s = sess();
    const res = await fetch(C.API_BASE + path, {
      ...opt, headers: { "Content-Type": "application/json", ...(s ? { Authorization: "Bearer " + s.token } : {}) }
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.message || body.error || "Request failed (" + res.status + ").");
    return body;
  }

  window.API = {
    demo, session: sess, domainOk,
    logout() { localStorage.removeItem(SK); },
    async login(email, password) {
      email = email.trim().toLowerCase();
      if (!domainOk(email)) throw new Error("Use your @" + C.ALLOWED_DOMAIN + " email address.");
      let s;
      if (demo) {
        if (password.length < 6) throw new Error("Password must be at least 6 characters.");
        seed();
        s = { token: "demo", email, role: C.DEMO_ADMIN_EMAILS.includes(email) ? "admin" : "student" };
      } else {
        const b = await http("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
        s = { token: b.token, email: (b.user && b.user.email) || email, role: (b.user && b.user.role) === "admin" ? "admin" : "student" };
      }
      localStorage.setItem(SK, JSON.stringify(s));
      return s;
    },
    async list() {
      const rows = demo ? (seed(), read()) : await http("/incidents");
      return (rows.incidents || rows).map(norm).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },
    async create(d) {
      const me = sess();
      if (!demo) return norm(await http("/incidents", { method: "POST", body: JSON.stringify(d) }));
      const row = { id: "n" + Date.now(), email: me.email, ...d, status: "Pending", createdAt: new Date().toISOString() };
      localStorage.setItem(DB, JSON.stringify([row, ...read()]));
      return norm(row);
    },
    async setStatus(id, status) {
      if (!demo) return http("/incidents/" + id, { method: "PATCH", body: JSON.stringify({ status }) });
      localStorage.setItem(DB, JSON.stringify(read().map(r => r.id === id ? { ...r, status } : r)));
    }
  };
})();
