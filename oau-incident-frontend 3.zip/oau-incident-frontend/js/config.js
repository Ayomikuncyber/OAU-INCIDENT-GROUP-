// Leave API_BASE empty to run in demo mode (data saved in this browser).
// Set it to your partner's backend URL, e.g. "https://api.example.com", to go live.
window.APP_CONFIG = {
  API_BASE: "",
  ALLOWED_DOMAIN: "oauife.edu.ng",
  DEMO_ADMIN_EMAILS: ["admin@oauife.edu.ng"] // demo mode only; the real backend decides roles
};
