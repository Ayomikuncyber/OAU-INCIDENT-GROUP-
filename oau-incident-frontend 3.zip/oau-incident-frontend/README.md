# OAU Incident System: frontend

Plain HTML, CSS and JavaScript. No build step. Open `index.html` in a browser, or serve the folder with any static host.

## Demo mode vs real backend
`js/config.js` has `API_BASE`. Empty = demo mode (seeded reports, saved in the browser's localStorage).
Set it to your partner's backend URL to go live. Sign in as `admin@oauife.edu.ng` in demo mode to see the admin dashboard.

## Admin dashboard (`#/admin`, Authority accounts only)
- Summary band: open, resolved, resolution rate, reports waiting more than 3 days, longest open report
- "Needs attention" queue: the oldest open reports with a one-click Mark resolved
- Reports per day (last 14 days) and open/resolved by category
- All reports table: status, category and sort filters, search (location, description, email), full reporter emails
- Bulk select with Mark resolved / Reopen, Undo on every status change, and CSV export of the filtered view
- Admins land here after sign-in; students who open `#/admin` are sent back to the feed

## Endpoints the frontend expects (edit `js/api.js` if yours differ)
- `POST /auth/login` `{email, password}` returns `{token, user:{email, role}}` (role `"admin"` or `"student"`)
- `GET /incidents` returns an array (or `{incidents:[...]}`) of `{id, email, category, location, description, status, created_at}`
- `POST /incidents` `{category, location, description}` (the backend should take the reporter email from the token)
- `PATCH /incidents/:id` `{status: "Resolved" | "Pending"}` (admins only)

Bulk actions send one `PATCH` per report. The @oauife.edu.ng rule and the admin-only check are enforced in the browser for convenience; the backend must enforce both too.
